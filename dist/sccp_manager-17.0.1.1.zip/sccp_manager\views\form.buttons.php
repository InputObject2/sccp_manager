<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$forminfo =array(
                array('name'=>'dev_buttons', 'label'=>'Buttons Configuration'),
                array('name'=>'button', 'label'=>'Buttons', 'help'=>'help')
                );
//$buttons_type=  array("empty","line","service","feature","speeddial");
//   "feature","service" -- Add leter !
$buttons_type=  array("empty","line","silent","monitor","speeddial","feature","adv.line");
$feature_list=  array('parkinglot'=>'Park Slots','monitor'=> "Record Calls",'devstate'=> "Change Status");

if (isset($_REQUEST['tech_hardware']) && $_REQUEST['tech_hardware'] === 'cisco') {
    $lines_list = $this->dbinterface->getSccpDeviceTableData('SccpExtension');
} else {
    $lines_list = $this->dbinterface->getSipTableData('extensionList');
}

$hint_list  = $this->getHintInformation(true, array('context'=>'park-hints')) ;

$line_id =0;
$max_buttons =56;     //Don't know hardware type so set a maximum. On save, this is set to actual max buttons
$show_buttons =1;
$db_device = array();
$db_buttons = array();

if (!empty($_REQUEST['id'])) {
    $dev_id = $_REQUEST['id'];
    $db_buttons = $this->dbinterface->getSccpDeviceTableData('get_sccpdevice_buttons', array("id" => $dev_id));
    $db_device = $this->dbinterface->getSccpDeviceTableData('get_sccpdevice_byid', array("id" => $dev_id));
    $db_device = is_array($db_device) ? $db_device : array();
    $show_buttons = (int)($db_device['buttons'] ?? 0);
    if (!empty($db_device['addon_buttons'])) {
        $show_buttons += (int)$db_device['addon_buttons'];
    }
}
if (!empty($_REQUEST['new_id'])) {
    $val = $_REQUEST['type'] ?? '';
    $dev_schema = $this->getSccpModelInformation('byid', false, "all", array('model' => $val));
    $show_buttons = (isset($dev_schema[0]['buttons']) ? (int)$dev_schema[0]['buttons'] : 1);
    if (!empty($_REQUEST['addon'])) {
        $val = $_REQUEST['addon'];
        $dev_schema = $this->getSccpModelInformation('byid', false, "all", array('model' => $val));
        $show_buttons += (isset($dev_schema[0]['buttons']) ? (int)$dev_schema[0]['buttons'] : 0);
    }
}
if (!empty($_REQUEST['ru_id'])) {
    $dev_id = $_REQUEST['ru_id'];
    $db_buttons = $this->dbinterface->getSccpDeviceTableData('get_sccpdevice_buttons', array("id" => $dev_id));
    $show_buttons = $max_buttons;
}

?>

<form autocomplete="off" name="frm_editbuttons" id="frm_editbuttons" class="fpbx-submit" action="" method="post" data-id="hw_edit">
    <input type="hidden" name="category" value="frm_editbuttons">
    <input type="hidden" name="Submit" value="Submit">
    <input type="hidden" name="buttonscount" id="buttonscount" value="<?php echo $this->escapeHtml($show_buttons);?>">
    <input type="hidden" name="devButtonCnt" id="devButtonCnt" value="<?php echo $this->escapeHtml(isset($db_device['buttons']) ? (int)$db_device['buttons'] : 0);?>">
    <input type="hidden" name="addonCnt" id="addonCnt" value="<?php echo $this->escapeHtml(isset($db_device['dns']) ? $db_device['dns'] : 0);?>">
    <div class="section-title" data-for="<?php echo $this->escapeHtml($forminfo[0]['name']);?>">
        <h3><i class="fa fa-minus"></i><?php echo _($forminfo[0]['label']) ?></h3>
    </div>
    <div class="section" data-id="<?php echo $this->escapeHtml($forminfo[0]['name']);?>">
    <div class="row"> <div class="form-group">
            <div class="col-sm-2">
                <label class="control-label"><?php echo _("Help"); ?></label>
                <i class="fa fa-question-circle fpbx-help-icon" data-for="frmbuttons"></i>
            </div>
            <div class="col-sm-10">
                <span id="frmbuttons-help" class="help-block fpbx-help-block"><?php echo _("buttons come in the following flavours: <br>
                    <ul>
                    <li>empty: Empty button (no options)</li>
                    <li>line: Registers the line with identifier specified as [name]</li>
                    <li>silent:   buttons equal 'Line' with out ring</li>
                    <li>monitor:  buttons mode speeddial + show status</li>
                    <li>speeddial: Adds a speeddial with label [name] and [option1] as number Optionally, [option2] can be used to specify a hint by extension@context as usual.</li>
                    <li>service (not implemented): Adds a service url Feature buttons have an on/off status represented on the device with a tick-box and can be used to set the device in a particular state. Currently Possible [option1],[option2] combinations:</li>
                    <ul>
                    <li>privacy,callpresent = Make a private call, number is suppressed</li><li>privacy,hint = Make a private call, hint is suppressed</li><li>cfwdall,number = Forward all calls </li><li>cfwbusy,number = Forward on busy</li><li>
                    cfwnoaswer,number = Forward on no-answer (not implemented yet)<br> DND,busy = Do-not-disturb, return Busy signal to Caller <br> DND,silent = Do-not-disturb, return nothing to caller <br>
                    monitor = Record Calls using AutoMon (asterisk 1.6.x only)</li><li>devstate,custom_devstate = Device State Feature Button (asterisk 1.6.1 and up). custom_devstate is the name of the custom devicestate to be toggled (How to use devicestate)
                    hold = To be implemented</li><li>transfer = To be implemented</li><li>multiblink = To be implemented</li><li>mobility = To be implemented</li><li>conference = To be implemented</li>
                    </ui></ui>");?></span>
            </div>

    </div></div>
    <?php
    for ($line_id = 0; $line_id <$max_buttons; $line_id ++) {
        $show_form_mode = '';
        $defaul_tv = (empty($db_buttons[$line_id])) ?  "empty": $db_buttons[$line_id]['buttontype'];
        $defaul_btn = (empty($db_buttons[$line_id])) ?  "": $db_buttons[$line_id]['name'];
        $button_options = (string)($db_buttons[$line_id]['options'] ?? '');
        $defaul_opt = ($button_options === '') ? array('') : explode(',', $button_options);

        $show_form_mode = $defaul_tv;
        $def_hint = '';       // Hint check Box
        $def_hint_btn = '';   // Hint Combo Box
        $def_park = '';       // Hint check Box
        $def_silent = '';
        $defaul_advline = '';
        $defaul_ftr = '';
        if (strpos($defaul_btn, '@') !== false) {
            $defaul_tv = 'adv.line';
            $show_form_mode = 'adv.line';
            $defaul_btn = strtok($defaul_btn, '@');
            $defaul_advline = strtok('@');
        }
        if ($line_id == 0) {
            $show_form_mode = 'line';
        }
        if (stripos($defaul_btn, '!') !== false) {
            $defaul_btn = strtok($defaul_btn, '!');
            $defaul_tv = 'silent';
            $def_silent = 'checked';
        }
        if ($defaul_tv == "feature") {
            $defaul_ftr = $defaul_opt[0];
            $defaul_fcod = (empty($defaul_opt[1])) ?  '': $defaul_opt[1];
            $def_park = (empty($defaul_opt[2])) ?  '': 'checked';
//                print_r($defaul_opt);
        }

        $is_hint_button = in_array($defaul_tv, array('speeddial', 'monitor'), true);
        foreach ($defaul_opt as $data_i) {
            if (strpos($data_i, '@') !== false) {
                if ($is_hint_button) {
                    $def_hint = 'checked';
                    $def_hint_btn = $data_i;
                    continue;
                }
                $test_btn = strtok($data_i, '@');
                $def_hint = 'checked';
                $defaul_btn = $data_i;
                $def_hint_btn = $data_i;
                if ($test_btn == $defaul_opt[0]) {
                    foreach ($lines_list as $data) {
                        if ($data['name']==$test_btn) {
                                $show_form_mode = 'line';
                                $defaul_tv = 'monitor';
                                $defaul_btn = $test_btn;
                                break;
                        }
                    }
                }
            }
        }

        echo '<!-- Begin button :' . $this->escapeHtml($line_id) . ' -->';
        echo '<div class="line_button element-container" '.(($line_id < $show_buttons)?"":"hidden ").'data-id="'.$this->escapeHtml($line_id).'">';

        ?>
            <div class="row"> <div class="form-group">
                    <div class="col-sm-2">
                        <label class="control-label" for="<?php echo $this->escapeHtml($forminfo[1]['name'].$line_id); ?> "><?php echo _($forminfo[1]['label'].$line_id).(($line_id =="0")?' '._("Default").' ':''); ?></label>
                    </div>
                    <div class="col-sm-5">
                        <div class="col-xs-3">
<!--  Line Type Select                        -->
                        <select class="form-control buttontype" data-id="<?php echo $this->escapeHtml($line_id);?>" name="<?php echo $this->escapeHtml($forminfo[1]['name'].$line_id.'_type');?>">
                    <?php
                    if ($line_id == 0) {
                        echo '<option value="line" selected >' . _("DEF LINE") . '</option>';
                    } else {
                        foreach ($buttons_type as $data) {
                            $select = (($data == $defaul_tv)?"selected":"");
                            echo '<option value="'.$this->escapeHtml($data).'" '.$select.' >'.$this->escapeHtml($data).'</option>';
                        }
                    }
                    ?>
                        </select>
                        </div>
<!--  if Line Type = feature Show Futures -->
                        <div class="col-xs-7">
                        <select data-type="feature" class ="futuretype form-control lineid_<?php echo $this->escapeHtml($line_id).(($show_form_mode=='feature')?'':' hidden');?>" data-id="<?php echo $this->escapeHtml($line_id);?>"  name="<?php echo $this->escapeHtml($forminfo[1]['name'].$line_id.'_feature');?>" >
                        <?php
                        foreach ($feature_list as $fkey => $fval) {
                            $select = (($fkey == $defaul_ftr)?"selected":"");
                            echo '<option value="'.$this->escapeHtml($fkey).'" '.$select.' >'.$this->escapeHtml($fval).'</option>';
                        }
                        ?>
                        </select>
<!--  if Line Type = line Show SCCP Num -->
                        <select data-type='line' class ="form-control lineid_<?php echo $this->escapeHtml($line_id).(($show_form_mode=='line' || $show_form_mode=='adv.line')?'':' hidden');?>" name="<?php echo $this->escapeHtml($forminfo[1]['name'].$line_id.'_line');?>" id="<?php echo $this->escapeHtml($forminfo[1]['name'].$line_id.'_line');?>">
                        <?php
                        foreach ($lines_list as $data) {
                            $select = (($data['name']==$defaul_btn)?'selected="selected"':"");
                            echo '<option value="'.$this->escapeHtml($data['name']).'" '.$select.' >'.$this->escapeHtml($data['name']).' / '.$this->escapeHtml($data['label']).'</option>';
                        }
                        ?>
                        </select>
<!--  if Line Type = Othe Show  Input -->
                        <div data-type='speeddial' class="lineid_<?php echo $line_id.(($show_form_mode=='speeddial')? '':' hidden');?>" >
                            <?php
                            echo '<input class="form-control" type="text" id="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_input').'"  name="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_input').'" placeholder="'._("Name").'" value="'.$this->escapeHtml($db_buttons[$line_id]['name'] ?? '').'" >';
                            ?>
                        </div>
                        </div>

                    </div>
                    <div class="col-md-5">
<!--  if Line Type = speeddial Show  Hint line -->
                        <div data-type='hintline' class="lineid_<?php echo $line_id.(($show_form_mode=='speeddial')? '':' hidden');?>" name="<?php echo $forminfo[1]['name'].$line_id.'_hint';?>">
                            <?php
                            echo '<div class="col-xs-5">';
                            echo '<input class="form-control" type="text" id="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_phone').'"  name="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_phone').'" placeholder="'._("Phone").'" value="'.$this->escapeHtml($defaul_opt[0] ?? '').'">';
                            echo '</div><div class="col-xs-2 radioset" data-toggle="buttons">';
                            echo '<input class="form-control" type="checkbox" name="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_hint').'" id="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_hint').'" '.$def_hint.' value="hint">';
                            echo '<label for="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_hint').'">'._("hints").'</label>';
                            echo '</div><div class="col-xs-5">';

                            echo '<select  class="form-control" name="'.$forminfo[1]['name'].$line_id.'_hline" >';
                            echo '<option value="">--</option>';

                            foreach ($hint_list as $data) {
                                $select = (($data['key']==$def_hint_btn)?"selected":"");
                                echo '<option value="'.$this->escapeHtml($data['key']).'" '.$select.' >'.$this->escapeHtml($data['exten']).' / '.$this->escapeHtml($data['label']).'</option>';
                            }
                            echo '</select>';
                            echo '</div>';
                            ?>
                        </div>
<!--  if Line Type = feature Show Futures  Park -->
                        <div data-type='feature' class="lineid_<?php echo $line_id.(($show_form_mode=='feature')? '':' hidden');?>" name="<?php echo $forminfo[1]['name'].$line_id.'_hint';?>">
                            <div class="col-xs-4">
                            <?php
                            echo '<input class="form-control" type="text" id="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_flabel').'"  name="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_flabel').'" placeholder="'._("Display Label").'" value="'.$this->escapeHtml($db_buttons[$line_id]['name'] ?? '').'" >';
                            ?>
                            </div>
                            <div class="col-xs-4">
                            <?php
                            echo '<input class="form-control" type="text" id="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_fvalue').'"  name="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_fvalue').'" placeholder="'._("code").'" value="'.$this->escapeHtml($defaul_fcod ?? '').'" >';
                            ?>
                            </div>
                        </div>
<!--  if Line Type = Advanced Show  Hint line -->

                        <div data-type='adv_line' class="lineid_<?php echo $line_id.(($show_form_mode=='adv.line')? '':' hidden');?>" name="<?php echo $forminfo[1]['name'].$line_id.'_hint';?>">
                            <div class="col-xs-5">
                            <?php
                            echo '<input class="form-control" type="text" id="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_advline').'"  name="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_advline').'" placeholder="[+=][01]:[cidname]" value="'.$this->escapeHtml($defaul_advline ?? '').'" >';
                            ?>
                            </div>
                            <div class="col-xs-5">
                            <?php
                            echo '<input class="form-control" type="text" id="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_advopt').'"  name="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_advopt').'" placeholder="'._("ButtonLabel,Options").'" value="'.$this->escapeHtml($db_buttons[$line_id]['options'] ?? '').'" >';
                            ?>
                            </div>
                        </div>
<!--  if Line Type = feature Show Futures  Park -->
                        <div data-type='featurep' class="lineid_<?php echo $line_id.(($show_form_mode=='feature')? (($defaul_ftr=='parkinglot')? ' ':' hidden'):' hidden');?>" name="<?php echo $forminfo[1]['name'].$line_id.'_park';?>">
                            <div class="col-xs-4">
                                <div class="radioset" data-toggle="buttons">
                            <?php
                                echo '<input class="form-control" type="checkbox" name="'.$forminfo[1]['name'].$line_id.'_retrieve" id="'.$forminfo[1]['name'].$line_id.'_retrieve" '.$def_park.' value="retrieve">';
                                echo '<label for="'.$this->escapeHtml($forminfo[1]['name'].$line_id.'_retrieve').'">'._("RetrieveSingle").'</label>';
                            ?>
                                </div>
                             </div>
                        </div>

                    </div>

                </div></div>
        </div>
        <?php
        echo '<!-- End button :'.$line_id.' -->';
    }

    ?>



    </div>
</form>
<div class="section-butom" data-for="<?php echo $forminfo[0]['name'];?>">
        <h3></h3>
</div>
